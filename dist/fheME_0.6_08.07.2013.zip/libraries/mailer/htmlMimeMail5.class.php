<?php
require_once(dirname(__FILE__) . '/htmlMimeMail5.php');
?>