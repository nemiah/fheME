<?php

interface iRSSDataParser {
	public function parse($data);
}

?>