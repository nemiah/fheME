<?php

/**
 * PHP_Timer
 *
 * Copyright (c) 2010-2013, Sebastian Bergmann <sebastian@phpunit.de>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 *   * Neither the name of Sebastian Bergmann nor the names of his
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    PHP
 * @subpackage Timer
 * @author     Sebastian Bergmann <sebastian@phpunit.de>
 * @copyright  2010-2013 Sebastian Bergmann <sebastian@phpunit.de>
 * @license    http://www.opensource.org/licenses/BSD-3-Clause  The BSD 3-Clause License
 * @link       http://github.com/sebastianbergmann/php-timer
 * @since      File available since Release 1.0.0
 */

/**
 * Utility class for timing.
 *
 * @package    PHP
 * @subpackage Timer
 * @author     Sebastian Bergmann <sebastian@phpunit.de>
 * @copyright  2010-2013 Sebastian Bergmann <sebastian@phpunit.de>
 * @license    http://www.opensource.org/licenses/BSD-3-Clause  The BSD 3-Clause License
 * @version    Release: @package_version@
 * @link       http://github.com/sebastianbergmann/php-timer
 * @since      Class available since Release 1.0.0
 */
class Timer {
	private static $enabled = false;
	/**
	 * @var array
	 */
	private static $times = array(
		'h' => 3600000,
		'm' => 60000,
		's' => 1000
	);

	/**
	 * @var array
	 */
	private static $startTimes = array();

	/**
	 * @var float
	 */
	public static $requestTime;

	public static $logged = array();
	
	/**
	 * Starts the timer.
	 */
	public static function start() {
		array_push(self::$startTimes, microtime(TRUE));
	}

	/**
	 * Stops the timer and returns the elapsed time.
	 *
	 * @return float
	 */
	public static function stop() {
		return microtime(TRUE) - array_pop(self::$startTimes);
	}

	/**
	 * Formats the elapsed time as a string.
	 *
	 * @param  float $time
	 * @return string
	 */
	public static function secondsToTimeString($time) {
		$ms = round($time * 1000);

		foreach (self::$times as $unit => $value) {
			if ($ms >= $value) {
				$time = floor($ms / $value * 100.0) / 100.0;
				return $time . ' ' . ($time == 1 ? $unit : $unit);
			}
		}

		return $ms . 'ms';
	}

	/**
	 * Formats the elapsed time since the start of the request as a string.
	 *
	 * @return string
	 */
	public static function timeSinceStartOfRequest() {
		return self::secondsToTimeString(microtime(TRUE) - self::$requestTime);
	}

	/**
	 * Returns the resources (time, memory) of the request as a string.
	 *
	 * @return string
	 */
	public static function resourceUsage() {
		return sprintf(
				'Time: %s, Memory: %4.2fMb', self::timeSinceStartOfRequest(), memory_get_peak_usage(TRUE) / 1048576
		);
	}
	
	public static function now($name, $file, $line){
		if(!self::$enabled)
			return;
		
		self::$logged[] = array(Util::makeFilename($name), self::timeSinceStartOfRequest(), basename($file), $line);
	}

	public static function getLogged(){
		return self::$logged;
	}
}

if (isset($_SERVER['REQUEST_TIME_FLOAT'])) {
	Timer::$requestTime = $_SERVER['REQUEST_TIME_FLOAT'];
} else {
	Timer::$requestTime = microtime(TRUE);
}
